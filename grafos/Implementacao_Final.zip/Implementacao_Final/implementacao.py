from collections import deque
import os

import matplotlib.pyplot as plt
import networkx as nx

class Grafo:
    def __init__(self, matriz_adjacencia):
        self.matriz_adjacencia = matriz_adjacencia
        self.num_vertices = len(matriz_adjacencia)
        self.visitado = [False] * self.num_vertices
        self.cor = [None] * self.num_vertices
        self.componentes_conexas = []

    def bfs(self, raiz):
        fila = deque()
        fila.append(raiz)
        self.visitado[raiz] = True
        componente = [raiz]

        while fila:
            v = fila.popleft()
            for u in range(self.num_vertices):
                if self.matriz_adjacencia[v][u] == 1 and not self.visitado[u]:
                    fila.append(u)
                    self.visitado[u] = True
                    componente.append(u)
                    self.cor[u] = not self.cor[v]  # Alternar a cor para bipartição

        self.componentes_conexas.append(componente)

    def verificar_conexo(self):
        return len(self.componentes_conexas) == 1

    def encontrar_biparticao(self):
        for v in range(self.num_vertices):
            if not self.visitado[v]:
                self.bfs(v)

    def mostrar_biparticao(self):
        if self.verificar_conexo():
            print("O grafo é conexo.")
            print("Bipartição:")
            for i in range(self.num_vertices):
                print(f"Vértice {i}: Grupo {'A' if self.cor[i] else 'B'}")
        else:
            print("O grafo não é conexo.")
            for i, componente in enumerate(self.componentes_conexas):
                print(f"Componente Conexa {i + 1}: {componente}")

    def mostrar_bfs(self, raiz):
        print("Busca em Largura:")
        fila = deque()
        fila.append(raiz)
        visitados_bfs = [False] * self.num_vertices

        while fila:
            v = fila.popleft()
            if not visitados_bfs[v]:
                print(f"Visitando vértice {v}")
                visitados_bfs[v] = True
                for u in range(self.num_vertices):
                    if self.matriz_adjacencia[v][u] == 1 and not visitados_bfs[u]:
                        fila.append(u)

    def encontrar_ciclo_impar(self, raiz):
        fila = deque()
        fila.append(raiz)
        nivel = [float('inf')] * self.num_vertices
        nivel[raiz] = 0

        while fila:
            v = fila.popleft()
            for u in range(self.num_vertices):
                if self.matriz_adjacencia[v][u] == 1:
                    if nivel[u] == float('inf'):
                        nivel[u] = nivel[v] + 1
                        fila.append(u)
                    elif nivel[v] % 2 == nivel[u] % 2:
                        return (nivel[v], nivel[u])

        return None

    def visualizar_grafo(self):
        G = nx.Graph()

        for i in range(self.num_vertices):
            G.add_node(i)

        for i in range(self.num_vertices):
            for j in range(i+1, self.num_vertices):
                if self.matriz_adjacencia[i][j] == 1:
                    G.add_edge(i, j)

        pos = nx.spring_layout(G)
        cores = ['red' if self.cor[i] else 'blue' for i in range(self.num_vertices)]

        nx.draw(G, pos, node_color=cores, with_labels=True)
        plt.show()

# Função para ler o arquivo "grafo.txt" e criar a matriz de adjacência
def ler_matriz_adjacencia(arquivo):
    try:
        with open(arquivo, 'r') as file:
            linhas = file.read().splitlines()
            matrizes_adjacencia = []
            matriz_atual = []

            for linha in linhas:
                if not linha.strip():  # Linha em branco indica o fim de uma matriz
                    if matriz_atual:  # Adicionar a matriz apenas se ela não for vazia
                        matrizes_adjacencia.append(matriz_atual)
                        matriz_atual = []
                else:
                    matriz_atual.append(list(map(int, linha.split())))

            if matriz_atual:  # Adicionar a última matriz se houver uma linha em branco no final
                matrizes_adjacencia.append(matriz_atual)

        return matrizes_adjacencia

    except FileNotFoundError:
        print(f"Arquivo '{arquivo}' não encontrado. Verifique o caminho do arquivo.")
        return []

# Função para imprimir a matriz de adjacência
def imprimir_matriz_adjacencia(matriz_adjacencia):
    for i in range(len(matriz_adjacencia)):
        print(matriz_adjacencia[i])

# Função principal
if __name__ == "__main__":
    nome_arquivo = "grafo.txt"
    matrizes_adjacencia = ler_matriz_adjacencia(nome_arquivo)
    

    print(f"Foram carregadas {len(matrizes_adjacencia)} matriz(es) de adjacência.")
    indice_matriz = int(input("Qual matriz deseja manipular? (Digite o índice): "))

    grafo = Grafo(matrizes_adjacencia[indice_matriz])
    
    imprimir_matriz_adjacencia(grafo.matriz_adjacencia)
    grafo.visualizar_grafo()

    for v in range(grafo.num_vertices):
        if not grafo.visitado[v]:
            grafo.bfs(v)
    
    opcao = input("Digite a Opção Desejada:\n1 Verificar se o grafo é conexo\n2 Aplicar Busca em Largura\n3 Encontrar Bipartição\n")

    if opcao == '1':
        if grafo.verificar_conexo():
            print("O grafo é conexo.")
            for i, componente in enumerate(grafo.componentes_conexas):
                print(f"Componente Conexa {i + 1}: {componente}")
        else:
            print("O grafo não é conexo.")

    elif opcao == '2':
        raiz_bfs = int(input("Qual será o vértice raiz da busca? "))
        grafo.mostrar_bfs(raiz_bfs)

    elif opcao == '3':
        grafo.encontrar_biparticao()
        grafo.mostrar_biparticao()

        ciclo_impar = grafo.encontrar_ciclo_impar(0)
        if ciclo_impar:
            print(f"O grafo possui um ciclo ímpar: {ciclo_impar[0]} e {ciclo_impar[1]}")
        else:
            print("O grafo é bipartido.")

        # Visualizar o grafo
        grafo.visualizar_grafo()

    else:
        print("Opção inválida.")
