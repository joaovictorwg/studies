import matplotlib.pyplot as plt
import networkx as nx

class Grafo:
    def __init__(self, matriz_adjacencia):
        self.matriz_adjacencia = matriz_adjacencia
        self.num_vertices = len(matriz_adjacencia)
        self.cor = [None] * self.num_vertices

    def visualizar_grafo(self):
        G = nx.Graph()

        for i in range(self.num_vertices):
            G.add_node(i)

        for i in range(self.num_vertices):
            for j in range(i+1, self.num_vertices):
                if self.matriz_adjacencia[i][j] == 1:
                    G.add_edge(i, j)

        cores = ['red' if self.cor[i] else 'blue' for i in range(self.num_vertices)]

        nx.draw(G, with_labels=True, node_color=cores, cmap=plt.cm.Blues)
        plt.show()

# Exemplo de uso
matriz_adjacencia = [
    [0, 0, 1, 1, 0, 0, 0, 1, 0, 0],
    [0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    [1, 0, 0, 1, 0, 0, 0, 0, 0, 0],
    [1, 0, 1, 0, 0, 1, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 1, 1, 0, 1, 0],
    [0, 0, 0, 1, 1, 0, 0, 0, 0, 0],
    [0, 1, 0, 0, 1, 0, 0, 1, 0, 0],
    [1, 0, 0, 0, 0, 0, 1, 0, 0, 1],
    [0, 0, 0, 0, 1, 0, 0, 0, 0, 1],
    [0, 0, 0, 0, 0, 0, 0, 1, 1, 0]
]

grafo = Grafo(matriz_adjacencia)
grafo.cor = [True, True, False, False, True, True, False, False, False, False]

grafo.visualizar_grafo()
